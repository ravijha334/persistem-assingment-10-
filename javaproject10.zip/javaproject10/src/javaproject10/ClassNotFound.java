package javaproject10;

public class ClassNotFound {
	public class ContactNotFound extends Exception {
		public ContactNotFound() {
			super("Contact Not Found");
		}
	}

}
